# RPGA Feather

import time
import board, busio
import oakdevtech_icepython
import gc

gc.collect()
print("Mem Free: ",gc.mem_free(),"Mem Alloc", gc.mem_alloc())

spi = busio.SPI(clock=board.F_SCK, MOSI=board.F_MOSI, MISO=board.F_MISO)

iceprog = oakdevtech_icepython.Oakdevtech_icepython(
    spi, board.F_CSN, board.F_RST, "top.bin"
)

timestamp = time.monotonic()

iceprog.program_fpga()

endstamp = time.monotonic()
print("******************************")
print("FPGA Program Done!")
print("Done in: ", (endstamp - timestamp), " seconds")
print("******************************")

import code_jgrub
