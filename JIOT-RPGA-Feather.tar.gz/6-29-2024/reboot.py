"""
Aventesia J-IOT : jcore, JTerminal
================================================================================
J-IOT for CircuitPython

* Author(s): Sean C Reichle

Implementation Notes
--------------------
Lots of Credit to Adafruit... yummy fruit.

Dynamic Web Server: J-IOT, JTerminal
No nonsense reboot now.
"""

import microcontroller
microcontroller.reset()