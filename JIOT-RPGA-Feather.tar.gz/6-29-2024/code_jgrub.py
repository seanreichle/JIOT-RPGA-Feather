"""
**********************************************************************
J-IOT by Adventesia
JPicoWeb, J98, J7

Jarvis, J, J-IOT
J7 on UM Feather S2
RPGA Feather

**********************************************************************
FPGA already Programmed
"""

# Disable Auto-reload
import supervisor
supervisor.set_next_code_file(filename = 'code.py', reload_on_error = False, reload_on_success = False)
supervisor.runtime.autoreload = False

#### My GRUB
from jgrub import *

mygrub = jgrub()

mygrub.addChoice("JDOS ) (default in 5 seconds)", "import jdos")
mygrub.addChoice("JLinux ) ", "import start_ljinux")
mygrub.addChoice("JShell ) ", "import jshell")
mygrub.addChoice("JREPL ) ", "import jrepl")
mygrub.addChoice("JDev ) ", "import start_jdev")
mygrub.addChoice("JTerminal ) ", "import start_jterminal")
mygrub.addChoice("Prog FPGA ) ", "mygrub.reset()")
mygrub.addChoice("Reset ) ", "mygrub.reset()")
mygrub.addChoice("Quit ) ", "mygrub.abort()") 

mygrub.run()
