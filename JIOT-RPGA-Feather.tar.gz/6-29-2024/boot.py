"""
**********************************************************************
J-IOT by Adventesia
JPicoWeb, Ljinux

JWio Jarvis
RPGA Feather...
**********************************************************************


from storage import getmount, remount, disable_usb_drive

try:
    from supervisor import disable_autoreload
except ImportError:
    from supervisor import runtime

    def disable_autoreload():
        runtime.autoreload = False


try:
    from supervisor import status_bar

    status_bar.console = False
    del status_bar
except ImportError:
    pass
print("-" * 16 + "\nL", end="")
devf = False
stash = ""
try:
    with open("/devm", "r") as f:
        stash = "Development mode file detected\n"
    devf = not devf
except OSError:
    pass
print("J", end="")
lj_mount = getmount("/")
print("I", end="")
#### J-IOT
i = p = s = m = v = ""
try:
    import sys
    i = sys.implementation # (name='circuitpython', version=(8, 1, 0), mpy=517)
    i = i.name
    p = sys.platform # 'MicroChip SAMD51'
except:
    i = "py"
    p = "silicon"
    
try:
    import os
    uname = os.uname()
    s = uname[0] # samd51
    v = uname[2] # version : 8.1.0
    m = uname[4] # 'Seeeduino Wio Terminal with samd51p19'
except:
    s = "bitboss"
    v = 0.1
    m = "yep"
    
### Unique drive label derived by context    
desired_label = "J-" + str(s)

if lj_mount.label != desired_label:
    remount("/", readonly=False)
    lj_mount.label = desired_label
    remount("/", readonly=True)
del desired_label, lj_mount
print("N", end="")
if not devf:
    try:
        disable_usb_drive()
    except RuntimeError:
        pass
print("U", end="")
disable_autoreload()

print("X boot core\n" + "-" * 16 + "\nOutput:\n" + stash)
del devf, stash, disable_autoreload, disable_usb_drive, remount, getmount
try:
    del runtime
except:
    pass
    
### Check Install...
# Update include path :/LjinuxRoot/lib
from sys import path
path.append("/LjinuxRoot/lib")
### Bill88 is the man.
"""
