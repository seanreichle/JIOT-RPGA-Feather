"""
**********************************************************************
J-IOT by Adventesia
JPicoWeb, J98, J7

Jarvis, J, J-IOT
J7 on UM Feather S2
RPGA Feather

**********************************************************************
"""
import time
import board, busio
import oakdevtech_icepython
import gc
gc.collect()
print("******************************)
print("** RPGA Feather **************)
print("Mem Free: ",gc.mem_free(),"Mem Alloc", gc.mem_alloc())
spi = busio.SPI(clock=board.F_SCK, MOSI=board.F_MOSI, MISO=board.F_MISO)

iceprog = oakdevtech_icepython.Oakdevtech_icepython(
    spi, board.F_CSN, board.F_RST, "top.bin"
)

timestamp = time.monotonic()

iceprog.program_fpga()

endstamp = time.monotonic()

print("******************************)
print("FPGA Program Done!")
print("done in: ", (endstamp - timestamp), "seconds")
print("******************************)
import start_ljinux

