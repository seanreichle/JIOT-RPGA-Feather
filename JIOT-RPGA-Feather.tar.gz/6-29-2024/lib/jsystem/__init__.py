"""
Aventesia Jarvis
================================================================================
Jarvis for CircuitPython
J-IOT, JTerminal, JPicoWeb, JESPWep, J98, J7, JGlass, Jarvis, JarvisJS

* Author(s): Sean C Reichle

Implementation Notes
--------------------

"""
#Adventesia 
#J-IOT, JTerminal, JGlass, Jarvis, JCloud, JGPIO
global J, jsys, jterm, jiot, jcloud, jhttp, JIOTID
global jpyOutput, jpyRawRequest, jpyRequest, jpyCode, jpyClient, jpyFile, jpyHeader

#DriveLabel by device
try:
    from storage import getmount
    drive = getmount("/")
    driveLabel = drive.label
    JIOTID = str(driveLabel)
except:
    pass

import json

#KeyValueStore object
#jsys.setkv("JIOTID", JIOTID)
#print(jsys.getkv("JIOTID"))
#print(JIOTID)
#print(jsys.kvstore.length())
#jsys.kvstore.listItems()

class JKeyValue:
    key:str
    value:str
    def __init__(self):
        self.key = ""
        self.value = ""
    
class JKeyValueStore():
    store:list
    def __init__(self):
        self.store = list()
        
    def setKeyValue(self, akey, avalue):
        kv = JKeyValue()
        kv.key = str(akey)
        kv.value = str(avalue)
        self.store.append(kv)
        
    def getValueForKey(self, akey):
        for kv in self.store:
            if kv.key == str(akey):
                return kv.value
                
    def setValueForKey(self, akey, avalue):
        result = False
        for kv in self.store:
            if kv.key == str(akey):
                kv.value = str(avalue)
                result = True
                break
        return result
             
    def removeKeyValue(self, akey):
        result = False
        oldStore = self.store
        self.store = list()
        for kv in oldStore:
            if kv.key != str(akey):
                self.store.append(kv)
            else:
                result = True
        return result
        
    def getStore(self):
        return self.store
        
    def listItems(self):
        for kv in self.store:
            print(kv.key + " = " + kv.value)
        
    def length(self):
        return len(self.store)
        

#JSystem global jsys
class JSystem():
    systemName:str
    owner:str
    ownerInterface:str
    running:bool
    keyValuejson:str
    kvstore: object
        
    def __init__(self):
        global jpyOutput, jpyRawRequest, jpyRequest, jpyCode, jpyClient, jpyFile, jpyHeader
        self.systemName = "#" * 40
        self.owner = "Adventesia Corp."
        self.ownerInterface = ""
        self.kvstore = JKeyValueStore()
        self.keyValuejson = "" # "[{'key':'','value':''}]"
        self.running = True
        
        try:
            jpyOutput = ""
            jpyRequest = ""
            jpyRawRequest = ""
            jpyClient = ""
            jpyHeader = ""
            jpyCode = ""
            jpyFile = ""
        except:
            pass
        
        
    def setSystemName(self, newSystemName):
        self.systemName = newSystemName
        self.createkv("JSystem::MailBox", "Ready")
        
    #-------------------
    #kv store
    def getkv(self, akey):
        return self.kvstore.getValueForKey(akey)
        
    def createkv(self, akey, avalue):
        self.kvstore.setKeyValue(akey, avalue)

    def setkv(self, akey, avalue):
        self.kvstore.setValueForKey(akey, avalue)
    
    def delkv(self, akey):
        return self.kvstore.removeKeyValue(akey)
    #-------------------
    
    def check(self):
        print(" -= J-IOT by Adventesia Corp. =- ")
        return self.systemName

    def user(self, location):
        self.ownerInterface = location
        
    def boot(self):
        #self ad
        self.check()
        #pins
        print('--------------------------------------------')
        import board
        import microcontroller
        print ("Pins:")
        board_pins = []
        for pin in dir(microcontroller.pin):
            if isinstance(getattr(microcontroller.pin, pin), microcontroller.Pin):
                pins = []
                for alias in dir(board):
                    if getattr(board, alias) is getattr(microcontroller.pin, pin):
                        pins.append("board.{}".format(alias))
                if len(pins) > 0:
                    board_pins.append(" ".join(pins))
        
        for pins in sorted(board_pins):
            print(pins)    
        
        #i2c
        """
        print('--------------------------------------------')
        import busio
        try:
            i2c = busio.I2C(board.SCL, board.SDA)
            while not i2c.try_lock():
                pass

            try:
                while True:
                    print(
                        "I2C addresses found:",
                        [hex(device_address) for device_address in i2c.scan()],
                    )
                    time.sleep(2)

            finally:  # unlock the i2c bus when ctrl-c'ing out of the loop
                i2c.unlock()
            print('--------------------------------------------')
        except:
            pass
        """
        
    def start(self):
        self.running = False
             
    def cpuCycle(self):
        devInput = self.getkv("DevConsoleInput")
        if devInput == "hello":
            self.setkv("DevConsoleOutput", "Hello there.\nThese are not the droids you are looking for.\n\nMove along...")
        elif devInput == "report":
            reportStr = "KVStore Size: " + len(self.kvstore) + "\n"
            self.setkv("DevConsoleOutput", reportStr)
            
    def run(self):
        self.running = True
        while (self.running == True):
            self.cpuCycle()
        print("End of Line")
    
    def shutdown(self):
        self.running = False

"""
##################################################################################################
from jsystem import jsystem
try:
    jsys = jsystem()
    jsys.boot()
    jsys.start()
except:
    jsys.check()

    
try:
    jsys.boot()
    jsys.start() #jsys(self/bot), jterm(serial/webterminal/console/shell), jiot(jhttp/api/webterminal)
    
    print("Up and running... @ " + str(jhttp.ipAddress))
    
    #jterm.welcomeMessage()
    #jterm.enableKeyboard()
    
    jsys.run()
except:
    jsys.check()

##################################################################################################    
"""