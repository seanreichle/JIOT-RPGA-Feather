"""
Aventesia Jarvis
================================================================================
Jarvis for CircuitPython
J-IOT, JTerminal, JPicoWeb, JESPWep, J98, J7, JGlass, Jarvis, JarvisJS

* Author(s): Sean C Reichle

Implementation Notes
--------------------
jgrub

"""

#### My GRUB
from jsystem import JSystem
import time
from supervisor import runtime
from sys import stdin

class jgrubChoice:
    key:str
    option:str
    codeDo:str
    
class jgrub():
    choices:list
    waitms:int
    start:int
    keyin:str
    myNow:int
    waiting:bool
    remaining:int
    
    jsystem:object
    def __init__(self):
        self.waitms = 5 * 1000000000 # a billion?
        self.remaining = self.waitms
        self.choices = list()
        self.start = time.monotonic_ns()
        self.myNow = self.start
        self.keyin = ""
        self.waiting = True
        self.jsystem = JSystem
    
    def setjsys(self, ajsysobject):
        self.jsystem = ajsysobject
        self.jsystem.createkv("JGrub::MailBox", "Ready")
        self.jsystem.setkv("DevConsoleOutput", "grub Loaded: ok")

    
    def cpuCycle(self):
        self.myNow = time.monotonic_ns()
        
        soDone = (self.start + self.waitms)
        self.remaining = soDone - self.myNow
        if (self.myNow > soDone):
            self.waiting = False
            self.emperorDoIt("1")
        
        if self.remaining ==  0 or self.remaining < 0:
            self.waiting = False
            self.emperorDoIt("1")
        
        #print(str(self.remaining))
        
    def keyCheck(self):
        while not runtime.serial_bytes_available and self.waiting==True :
            self.cpuCycle()
        self.keyin = stdin.read(1)
        return(self.keyin)   
    
    def addChoice(self, achoice, someCode):
        thisChoice = jgrubChoice()
        thisChoice.index = str(len(self.choices) + 1)
        thisChoice.option = achoice
        thisChoice.codeDo = someCode
        self.choices.append(thisChoice)

    def clearScreen(self):
        print(chr(27)+"[2J")
        
    def displayChoices(self):
        self.clearScreen()
        print(" -= J-IOT by Adventesia Corp. =- ")
        print(":: J7 jgrub bootloader\n")
        ci = 1
        for choice in self.choices:
            print(str(ci) + ") " + str(choice.option))
            ci+=1
        self.start = time.monotonic_ns()
        self.waiting = True
    
    def emperorDoIt(self, achoicebykey):
        for choice in self.choices:
            if str(choice.index) == achoicebykey:
                print(str(choice.option))
                print("Executing: " + str(choice.codeDo))
                #try:
                exec(str(choice.codeDo))
                #except:
                #self.abort()
                #print("Uhm.. something went wrong..")
                

    def sendCtrlC(self):
        print(chr(0x03))
    
    def sendCtrlD(self):
        print(chr(0x04))
    
    def abort(self):
        self.waiting= False
        self.remaining = 0 
    
    def quit(self):
        try:
            from sys import exit
            exit()
        except:
            pass
            
            
    def reset(self):
        try:
            import microcontroller
            microcontroller.reset()
        except:
            pass

    def run(self):
        while self.waiting:
            self.displayChoices()
            doThing = ""
            while doThing == "" and self.waiting==True :
                doThing = self.keyCheck()
            
            if doThing:
                self.emperorDoIt(doThing)
                
            self.abort()
           
        