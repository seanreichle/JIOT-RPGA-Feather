"""
Aventesia Jarvis
================================================================================
Jarvis for CircuitPython
J-IOT, JTerminal, JPicoWeb, JESPWep, J98, J7, JGlass, Jarvis, JarvisJS

* Author(s): Sean C Reichle

Implementation Notes
--------------------
JTerminal Dumptser Fire Kernal.... 

"""
#Circuitpython || Micropython
from sys import implementation
from jsystem import JSystem

#J-IOT, JTerminal, JGlass, Jarvis, JCloud, JGPIO
global jsys, J, jiot, jcloud, jhttp
global jpyOutput, jpyRawRequest, jpyRequest, jpyCode, jpyClient, jpyFile, jpyHeader


def bootProgress():
    global jsys
    return len(jsys)

def toConsole(messageToScreen):
    print(messageToScreen)
    
def jrun(task):    
    returnObject = []
    
    #Platform Check
    if task == "platformCheck":
        platform = implementation.name.upper()
        returnObject.append(platform)
        
        if platform == "CIRCUITPYTHON":
            from supervisor import runtime
            
        elif platform == "MICROPYTHON":
            from micropython import mem_info
        
    return returnObject