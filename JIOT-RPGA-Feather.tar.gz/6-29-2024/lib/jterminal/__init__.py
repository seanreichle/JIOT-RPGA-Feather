"""
Aventesia Jarvis
================================================================================
Jarvis for CircuitPython
J-IOT, JTerminal, JPicoWeb, JESPWep, J98, J7, JGlass, Jarvis, JarvisJS

* Author(s): Sean C Reichle

Implementation Notes
--------------------
JTerminal Dumptser Fire Kernal.... halt and catch fire
Incomming command queue from Init UART Serial.
Incomming command queue from Terminal Console Keyboard JREPL >>
Incomming command queue from JGlass Serial Console, J98, J7 
Enable/Disable Status->JTerminal Web Console
Enable/Disable Serial Comaand Execution
Enable/Disable Keyboard Monitoring

Incomming Code Stream Execution
JyperText Transfer Protocol
JText

Reboot

"""


#Adventesia 
#J-IOT, JTerminal, JGlass, Jarvis, JCloud, JGPIO
global J, jsys, jiot, jcloud, jhttp
global jpyOutput, jpyRawRequest, jpyRequest, jpyCode, jpyClient, jpyFile, jpyHeader
#UART the most powerful of them all.


#Begin JTerminal
#version
JIOTV = 1.0

#Boot
from jsystem import JSystem
from jterminal.termfunctions import *
"""
if jSystem:
    toConsole("JTerminal Booting...")
    
    from jterminal import termfunctions
else:
    from sys import exit
    print("This system does not meet the requirements for J-IOT.")
    exit()
"""

try:    
    import time
    import board
    import os
    import gc
    import board
    import busio
    import storage
    from os import statvfs
    import microcontroller
    from sys import stdin, implementation, path
    from supervisor import runtime
except:
    toConsole("J-IOT was designed to run on Circuitpython.")
    #import jdos
    
jrun("platformCheck")

def human_readable(whatever):
    if whatever < 1024:  # kb
        return str(int(whatever)) + "b"
    elif whatever < 1048576:  # mb
        return str( int(whatever/1024) )+ " K"
    elif whatever < 1073741824:  # gb
        return str( int(whatever/1048576) )+ " M"
    else:
        return str( int(whatever/1073741824) ) + " G"

# disk
dfr = statvfs("/")  # board
free = dfr[1] * dfr[3]
bs = 2
bs_sps = " " * bs
vfree = (human_readable(free))

# os
info = os.uname()

# mem
gc.collect()

#temp
temp = "N/A"
try:
    temp = microcontroller.cpu.temperature
except:
    pass

#JTerminal Utilizes a serial port... uart busio object
try:
    import busio
    #uartio = busio.UART(board.GP16, board.GP17,baudrate=9600)
except:
    toConsole
    pass
    
class fakeUART():
    def __init__(self, txpin, rxpin, abaudrate):
        pass
    def write(self):
        pass
    def read(self, anum):
        pass
    
class jTerminal():
    rxBuffer:str
    uart:object
    txPin:object
    rxPin:object
    baudrate:int
    
    identity:str
    selector:str
    
    mode:str
    
    #serial monitor on/off
    on:bool
    
    #J98 Status/JTerminal Support
    webConsoleTx:str
    webConsoleActive:bool
    commandsRx:str
    bufferSize:int
    
    #JTerminal Consle
    #keyboard buffer
    keyboard:str
    consoleOn:bool
    keyIn:bytearray
    
    #clean console helpers
    supress:bool
    
    #J-IOT JTerminal Version
    ver : float
    localTerminal:bool
    
    #jsys support
    jsystem:object
    
    def __init__(self, aUart=busio):
        self.identity = "IOT"
        self.rxBuffer = ""
        self.uart = aUart
        self.baudrate = 9600
        self.txPin = object
        self.rxPin = object
        self.selector = ""
        self.mode = "1" #polling rx pin
        self.webConsoleTx = ""
        self.commandsRx = ""
        self.bufferSize = 64 * 1 # 1kb
        self.webConsoleActive = False
        self.keyboard = ""
        self.consoleOn = False
        self.supress = False
        self.keyIn = bytearray()
        self.localTerminal = True
        self.on = False
        
        global JIOTV
        self.ver = JIOTV
        
        self.jsystem = JSystem
        
    def setjsys(self, ajsysobject):
        self.jsystem = ajsysobject
        self.jsystem.createkv("JTerminal::MailBox", "Ready")
        self.jsystem.setkv("DevConsoleOutput", "jTerminal Loaded: ok")
        
    def setIdentity(self, newIdent):
        self.identity = newIdent
    
    def getIdentity(self):
        return self.identity
        
    def about(self):
        retData = ""
        import os
        info = os.uname()
        retData += info[4]
        return str(retData)

    def mem(self):
        import gc
        gc.collect()
        vmem = human_readable(gc.mem_free())
        return str(vmem)
    
    def disk(self):
        from os import statvfs
        dfr = statvfs("/")  # board
        free = dfr[1] * dfr[3]
        bs = 2
        bs_sps = " " * bs
        vfree = (human_readable(free))
        return str(vfree)
        
    def enableKeyboard(self):
        self.consoleOn = True
        
    def disableKeyboard(self):
        self.consoleOn = False
    
    def setPins(self, newTxPin, newRxPin):
        self.txPin = newTxPin
        self.rxPin = newRxPin 
        
    def assignUart(self, newUart):
        try:
            self.uart = newUart
        except:
            print("Failed to bring up UART on assign.")
        
    def reConnectSerial(self):
        if self.on == False and self.txPin and self.rxPin and self.baudrate:
            try:
                self.uart = busio.UART(self.txPin, self.rxPin, baudrate=self.baudrate)
                print("UART UP")
                self.switchOn()
            except:
                print("Failed to bring up UART.")
                pass
        
    def disconnect(self):
        self.on = False
        self.uart = object
        
    def setBaudrate(self, newBaudrate):
        self.baudrate = newBaudrate
        
    def setBufferSize(self, newBufferSize=64):
        self.bufferSize = newBufferSize
        if self.bufferSize < 64:
            self.bufferSize = 64
        
    def poll(self):
        data_string = ""
        if self.on:
            try:
                data = self.uart.read(1)
                if data is not None:
                    data_string = ''.join([chr(b) for b in data])
            except:
                pass
        return data_string

    def readChunk(self):
        if self.on:
            data = None
            try:
                data = self.uart.read(32)
            except:
                pass
            if data is not None :
                data_string = ''.join([chr(b) for b in data])
                self.rxBuffer += data_string
                self.readChunk()

    def rx(self):
        if self.on:
            data = None
            try:
                data = self.uart.read(1)
            except:
                pass
                
            if data is not None :
                data_string = ''.join([chr(b) for b in data])
                self.rxBuffer += data_string
                self.rx()
            return self.rxBuffer
    
    def clearBuffers(self):
        self.rxBuffer=""
        
    def checkRxBuffer(self):
        if len(self.rxBuffer) > self.bufferSize:
            print("RX buffer dump: \n" + str(self.rxBuffer))
            self.clearBuffers()        
    
    def webConsoleGreeting(self):
        retData = ""
        retData += str("  ------------------------------------------------------\n")
        retData += str("-- Welcome to JTerminal Dumpster Fire Kernal --\n")
        retData += str("  ------------------------------------------------------\n")
        retData += str("J-IOT on " + str(implementation.name)+"\n")
        retData += str(info.machine)+"\n"
        retData += str("Serial @" + str(self.baudrate) + " :: On TX Pin: "+ str(self.txPin) + " RX :" + str(self.rxPin) + "\n")
        retData += str("Remote: " + str(self.on) + "\n")
        retData += str("\n") 
        try:
            import microcontroller
            retData += str("CPU Freq : " +str(microcontroller.cpu.frequency/1000000) + " MHz\n")
            retData += str("CPU Temp : " +str(microcontroller.cpu.temperature) + " c\n")
            retData += str("CPU Power: " +str(microcontroller.cpu.voltage) + " volts\n")
        except:
            pass

        gc.collect()
        retData += str("Free RAM: " + str(human_readable(gc.mem_free())) + "\n")
        retData += str("Free Disk: " + str(vfree) + "\n")
        retData += '\nJ >> '
        self.webConsoleTx += retData
        
    def webConsoleGet(self):
        getData = ""
        getData += self.webConsoleTx
        self.webConsoleTx = ""
        return getData
        
    def webConsolePrompt(self):
        self.consoleTx('\nJ >> ')
    
    def webConsoleCommand(self, cmd="\n"):
        #register
        aCmd = cmd.strip()
        self.commandsRx += aCmd + "\n"
        
    def consoleRx(self, rx):
        self.rxBuffer += rx
    
    def consoleTx(self, tx):
        self.webConsoleTx += tx

    def urldecode(self, aStr):
        dic = {"%20":" ","%21":"!","%22":'"',"%23":"#","%24":"$","%26":"&","%27":"'","%28":"(","%29":")","%2A":"*","%2B":"+","%2C":",","%2F":"/","%3A":":","%3B":";","%3D":"=","%3F":"?","%40":"@","%5B":"[","%5D":"]","%7B":"{","%7D":"}"}
        for k,v in dic.items(): 
            aStr=aStr.replace(k,v)
        return aStr

    def welcomeMessage(self):
        self.send("------------------------------------------------------\n")
        self.send("-- Welcome to JTerminal Dumpster Fire Kernal --\n")
        self.send("------------------------------------------------------\n")
        self.send("J-IOT on " + str(implementation.name)+"\n")
        self.send(str(info.machine)+"\n")
        self.send("Serial @" + str(self.baudrate) )
        self.send("On TX Pin: "+ str(self.txPin) + " RX :" + str(self.rxPin) + "\n")
        self.send("\n")
        try:
            import microcontroller
            self.send("CPU Freq : " +str(microcontroller.cpu.frequency/1000000) + " MHz\n")
            self.send("CPU Temp : " +str(microcontroller.cpu.temperature) + " c\n")
            self.send("CPU Power: " +str(microcontroller.cpu.voltage) + " volts\n")
        except:
            pass
        gc.collect()
        self.send("Free RAM: " + str(human_readable(gc.mem_free())) + "\n")
        self.send("Free Disk: " + str(vfree) + "\n")
        self.send("Temp: " + str(temp) + "\n")
        
    def prompt(self):
        if self.on:
            self.uart.write(bytearray('\nJ >>'))
    
    def process(self):
        if self.on:
            rxChar = self.poll()
            if len(rxChar) > 0:
                if rxChar == ".":
                    self.mode = self.poll()                
                else:
                    self.rxBuffer += rxChar 
                    self.poll()
       
    def send(self, aString):
        if self.on:
            self.uart.write(bytearray(aString))
    
    def announce(self, aString):
        print(aString)
        self.send("\n" + aString + "\n")
        self.consoleTx("\n" + aString + "\n")
        
    def ver(self):
        return " v" + str(self.ver)
        
    def boot(self):
        #self.clearScreen()
        self.announce(" -= J-IOT by Adventesia Corp. =- ")
        self.announce(":: JTerminal " + str(self.ver) + " REPL Layer")
        self.announce("Free RAM: " + str(self.mem()))
        self.announce("Free Disk: " + str(self.disk()))
        self.cpuCycle()
        
    def activeMonitor(self):
        try: 
            self.switchOn()
        except:
            print("Failed to bring up UART.")
        
        if self.on:
            self.announce("Running RxBuffer Monitor..")
            print("TX: " + str(self.txPin) + " :: RX: " + str(self.rxPin) )
            print("UART: " + str(self.uart))

        self.shellHeader()
        print("RX Buffer Size: " + str(self.bufferSize))

        self.enableKeyboard()
        print("::Monitor Mode")
        while self.consoleOn == True:
            self.cpuCycle()
        
    def shell(self):
        self.enterShell()
        
    def enterShell(self):
        self.localTerminal = True
        while self.localTerminal == True:
            self.localTerminalShell()
    
    def exitShell(self):
        self.localTerminal = False

    def shellHeader(self):
        dorx = " "
        if self.consoleOn:
            dorx = "X"
        doweb = " "
        if self.webConsoleActive:
            doweb = "X"
        muart = " "
        if self.on:
            muart = "X"
        print("UART Monitoring ["+muart+"]")
        print("Executing: " + "Shell[X]" + " :: " + "UARTRX["+dorx+"]" + " :: " + "WebTerm["+doweb+"]")
    
    def localPrompt(self):
        self.shellHeader()
        print("RX Monitoring halted, awaiting command:")
        userInput = input("J>>>")
        return userInput
        
    def localTerminalShell(self):
        global jpyOutput
        print()
        print(" -= Welcome to JTerminal Shell =-")
        while self.localTerminal == True:
            #flush RX buffer 
            if len(self.rxBuffer) > 0 : 
                print("RX: " + str(self.rxBuffer) + "\n")
                self.rxBuffer = ""
                
            #halt rx and input command
            command = self.localPrompt()
                
            if command == "exit" or command == "EXIT":
                self.localTerminal = False
                self.disableKeyboard()
                self.announce("Exiting JTerminal... ")
                self.announce("End of Line")
                
            elif command == "done" or command == "DONE":
                self.localTerminal = False
                
            elif command == "help" or command == "HELP":
                self.shellHelp() 
                
            elif command == "cls" or command == "CLS":
                self.clearScreen()
                
            elif command == "info" or command == "INFO":
                self.info()
                
            elif command[0:2] == "TX" or command[0:2] == "tx":
                print("____________________________________")
                print("Sending: " + str(command[2:]))
                print("____________________________________")
                self.send(command[2:]) 
                self.localTerminal = False                

            elif command == "" or command[0:2] == "RX" or command[0:2] == "rx":
                self.localTerminal = False
            
            elif command[0:3] == "DRX" or command[0:3] == "drx":
                self.on = False
                
            elif command[0:3] == "ERX" or command[0:3] == "erx":
                self.on = True

            elif command[0:4] == "DWEB" or command[0:4] == "dweb":
                self.webConsoleActive = False
                
            elif command[0:4] == "EWEB" or command[0:4] == "eweb":
                self.webConsoleActive = True
                     
            else:
                print("Executing: " + command)
                try:
                    jpyOutput = ""
                    print(exec(command))
                    if len(jpyOutput) > 0:
                        print(jpyOutput)
                        jpyOutput = ""
                except:
                    print("Invalid Python")
            
            self.cpuCycle()
                    
                
    def shellHelp(self):
        self.clearScreen()
        print("____HELP me REPL, you are my only hope____")
        print("HELP \t: This Help.")
        print("CLS  \t: Clear Screen.")
        print("EXIT \t: Exit JTerminal Shell to CircuitPython REPL.")
        print("TX \t: Send to UART TX Buffer.")
        print("RX \t: Resume RX monitoring.")
        print("[Empty] \t: Same as RX, press any key for prompt.")        
        print("DRX \t: Disable UART RX execution.")
        print("ERX \t: Enable UART RX execution.")
        print("DWEB \t: Deactivate JPicoWeb JTerminal Execution.")
        print("EWEB \t: Activate Web Terminal Execution.")
        print("INFO \t: Show Implementation")
        print("import [file.py] \t: duh.")
        print("[/path/file.jpy] \t: Debug .jpy files.")
        print("import jdos \t: PyDOS included in J-IOT.")
        print("import jbasic \t: PyBasic included in J-IOT.")
        print()
        
    def info(self):
        print()
        print("____Years ago you served my board____")
        print("import jterminal")
        print("jterm = jTerminal(optional uart)")
        print("jterm.shell() #J>>>full passthrough python w/help...")
        print("jterm.activeMonitor() #J >> JTerminal Commands")
        print()
        
    def reboot(self):
        self.announce("JTereminal Rebooting...")
        self.stop()
        for delay in range(1000):
            self.cpuCycle()
        import microcontroller 
        microcontroller.reset()
    
    def breakout(self):
        print("Breaking out of code execution.")
        try:
            from sys import exit
            exit()
        except:
            print(chr(0x04))
            pass
        
    def executeCommands(self):
        #process
        commands = (self.commandsRx).split("\n")
        self.commandsRx = ""        
        for cmd in commands:
            if len(cmd) > 1:
                self.consoleTx("\n--- Executing: " + cmd + "\n")
            
            cmd = cmd + "\n"
            if cmd == "\n":
                self.webConsolePrompt()
                
            elif cmd == "hello\n":
                self.consoleTx("\nGreetings Sir.\n")
                self.webConsoleActive = True
                self.on = True
                self.mode = "1"
                #self.webConsoleGreeting()
                self.webConsolePrompt()
                
            elif cmd == "reboot\n":
                if self.self.webConsoleActive:
                    self.consoleTx("\nRebooting Sir.\n")
                    for x in range(1000):
                        self.cpuCycle()
                    self.reboot()
                    
            elif cmd == "stat\n":
                self.consoleTx("\nReceive Buffer: " + str(len(self.rxBuffer)) + "\n")
                
            elif cmd == "bye\n" or cmd == "logout\n":
                if self.webConsoleActive:
                    self.consoleTx("\nGoodbye Sir.\n")
                    self.webConsoleActive = False
                
            elif cmd == "on\n":
                if self.webConsoleActive:
                    self.on = True
                    self.mode = "1"
                    self.announce("JTereminal On...")
            
            elif cmd == "off\n":
                if self.webConsoleActive:
                    self.off()
                    
            elif cmd == "shell\n":
                self.shell()
                
            elif cmd.startswith("patch "):
                if self.self.webConsoleActive:
                    pass
            else:
                self.consoleTx("\nEnd of Line\n")
        
       
    #jBus Serial Bus Protocol for JTerminal    
    def jBusProcess(self):
        if self.mode == "1":
            pass
        elif self.mode == "2":
            #Receive and execute code.
            self.mode = "1"
            self.rxBuffer = ""
            self.readChunk()
            print("Executing: ")
            print(self.rxBuffer)
            try:
                exec(strip(self.rxBuffer))
                self.rxBuffer = ""
            except:
                pass
            self.prompt()
            
        elif self.mode == "3":
            #Receive and Render to Console, same as just typing...
            self.mode = "1"
            self.rxBuffer = ""
            self.readChunk()
            print(str(self.rxBuffer))
            self.rxBuffer=""
            self.prompt()
            
        elif self.mode == "4":
            #Receive a Selector Identifier, save and hold it.
            self.mode = "1"
            self.rxBuffer = ""
            self.readChunk()
            self.selector = self.rxBuffer
            self.rxBuffer = ""
            self.prompt()
            
        elif self.mode == "5":
            #Send stored selector identifier
            self.mode = "1"
            self.send(str(self.selector))
            self.prompt()
            
        elif self.mode == "6":
            #Start Webserver 
            self.mode = "1"
            self.notice("Starting JWebserver...")
            self.send("\nStarting JWebserver...\n")
            import start_jhttp
            self.notice("Webserver Stopped.")
            self.send("\JWebserver Stopped.\n")
            self.welcomeMessage()
            self.prompt()
            
        elif self.mode == "d" or self.mode == "D":
            #DOS
            self.mode = "1"
            self.announce("Starting JDOS...")
            import jdos
            self.welcomeMessage()
            self.prompt()
            
        elif self.mode == "r" or self.mode == "R":
            #Report
            self.mode = "1"
            print("____________________________________")
            print("-- Kernel Report -------------------")
            print("____________________________________")
            print("We're all fine here, everything's fine.")
            print("How are you?")
            self.send("----------------------------\n")
            self.send("-- Kernel Report -----------\n")
            self.send("----------------------------\n")
            self.send("We're all fine here, everything's fine.\n")
            self.send("How are you?\n\n")
            try:
                import microcontroller
                self.send("CPU Freq : " +str(microcontroller.cpu.frequency/1000000) + " MHz\n")
                self.send("CPU Temp : " +str(microcontroller.cpu.temperature) + " c\n")
                self.send("CPU Power: " +str(microcontroller.cpu.voltage) + " volts\n")
            except:
                pass
            gc.collect()
            self.send("Free RAM: " + str(human_readable(gc.mem_free())) + "\n")
            self.send("Free Disk: " + str(vfree) + "\n")                    
            self.prompt()
            
        elif self.mode == "x" or self.mode == "X":
            #Reboot
            self.mode = "1"
            self.reboot()
            
        elif self.mode == "t" or self.mode == "T":
            #Switch to Terminal at USB Console
            import os
            self.mode = "1"
            self.send("\nJTerminal : Waiting for command input at device console\n")
            print("-- Welcome to JTerminal Dumpster Fire Kernal --")
            print("J >>")
            cmdLine = input("J >"+os.getcwd()+">")
            print("JTerminal : Executing .. " + cmdLine)
            try:
                self.send("\nJTerminal : Executing .. " + cmdLine + " : \n")
                status = exec(cmdLine)
                self.send("\nStatus: " + str(status))
            except:
                pass
            self.prompt()
            
        elif self.mode == "l" or self.mode == "L":
            self.mode = "1"
            self.send("Command Queue:\n" + (self.commandsRx).split("\n") + "\n")
            self.prompt()
            
        elif self.mode == "e" or self.mode == "E":
            self.switchOn()
           
        else:
            self.mode = "1"     
    
    def cpuCycle(self):
        try:
            devInput = self.jsystem.getkv("DevConsoleInput")
            if devInput == "hello":
                self.jsystem.setkv("DevConsoleOutput", "J >>")
            elif devInput == "report":
                reportStr = "Free RAM: " + str(self.mem()) + "\n" + "Free Disk: " + str(self.disk())
                self.jsystem.setkv("DevConsoleOutput", reportStr)
        except:
            pass
            
        #JTerminal backend executioner
        if len(self.commandsRx) > 0 :
            self.executeCommands()
            
        #Serial JTerminal Monitor 
        if self.on:
            self.checkRxBuffer()
            #Main JTerminal Serial Monitor
            self.process()
            #Process incoming uart input stream
            self.jBusProcess()
        
        #USB Console JTerminal Monitor
        #What can it do... 
        #Keyboard input stream monitor
        if self.consoleOn and runtime.serial_bytes_available:
            self.keyIn = stdin.read(1)
            if self.keyIn == "\n":
                self.commandsRx += self.keyboard + "\n"
                self.rxBuffer += self.keyboard + "\n"
                self.keyboard = ""
            elif self.keyIn == ".":
                self.keyboard = ""
                userInput = input("J >>")
                print("Input Length :" + str(len(userInput)))
                if len(userInput) == 0:
                    pass
                elif len(userInput) == 1:
                    self.mode = userInput
                    self.jBusProcess()
                else:
                    self.commandsRx += userInput + "\n"
                    
            else:
                self.keyboard += self.keyIn
                self.rxBuffer += self.keyIn 
            
    
    def clearScreen(self):
        print(chr(27)+"[2J")

    def notice(self, title):
        self.announce("____________________________________")
        self.announce(str(title))        
        self.announce("____________________________________")
        
    def start(self):
        if self.on:
            self.announce("____________________________________")
            self.announce("Starting JTerminal...")
            self.announce("____________________________________")        
            self.welcomeMessage()
            self.prompt()
            self.process()
 
    def switchOn(self): 
        self.on = True
        self.mode = "0"
        self.announce("JTereminal On...")
        
    def stop(self):
        self.on = False
        self.mode = "0"
        self.announce("JTereminal Off...")
        
    def off(self):
        self.on = False
        self.announce("JTereminal Off...")
    
    def abort(self):
        #abort, drop into DOS Prompt
        import jdos
        
    def wait(self):
        print("Press any key to continue...")
        while self.keyIn == "":
            theAnyKey = self.keyCheck()
        return theAnyKey
        
    def keyCheck(self):
        self.keyIn = ""
        while not runtime.serial_bytes_available:
            pass            
        self.keyIn = stdin.read(1)
        return(self.keyIn)    

                