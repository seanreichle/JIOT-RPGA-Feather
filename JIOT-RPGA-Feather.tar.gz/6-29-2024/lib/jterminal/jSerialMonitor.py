import time
import board
import busio

uart = busio.UART(board.GP16, board.GP17,baudrate=9600)
rxBuffer = ""        
mode = "1"

def jTerminalReadPOLE():
    data_string = ""
    data = uart.read(1)
    if data is not None:
        data_string = ''.join([chr(b) for b in data])
    return data_string

def jTerminalReadChunk():
    global rxBuffer
    data = None
    try:
        data = uart.read(32)
    except:
        pass
    if data is not None :
        data_string = ''.join([chr(b) for b in data])
        rxBuffer += data_string
        jTerminalReadChunk()
    
def jTerminalReply():
    #uart.write(bytearray('Greetings Program!'))
    #Perhaps no reply for now.
    pass
    
def jTerminalPrompt():
    uart.write(bytearray('J >>'))

selector = ""    
def jTerminal():
    global rxBuffer, selector
    mode = "1"
    jTerminalPrompt()
    while True:
        rxChar = jTerminalReadPOLE()
        if len(rxChar) > 0:
            if rxChar == ".":
                mode = jTerminalReadPOLE()
            elif rxChar == "~":
                return
            elif rxChar == chr(10):
                print(rxBuffer)
                rxBuffer = ""
            else:
                rxBuffer += rxChar             
       
        if mode == "1":
            pass
        elif mode == "2":
            #Receive and execute code.
            mode = "1"
            rxBuffer = ""
            jTerminalReadChunk()
            print("Executing: ")
            print(rxBuffer)
            try:
                exec(strip(rxBuffer))
                rxBuffer = ""
            except:
                pass
            jTerminalPrompt()                
        elif mode == "3":
            #Receive and Render to Console
            mode = "1"
            rxBuffer = ""
            jTerminalReadChunk()
            print(str(rxBuffer))
            rxBuffer=""
            jTerminalPrompt()
        elif mode == "4":
            #Receive a Selector Identifier, save and hold it.
            mode = "1"
            rxBuffer = ""
            jTerminalReadChunk()
            selector = rxBuffer
            rxBuffer = ""
        elif mode == "5":
            #Send stored selector identifier
            mode = "1"
            uart.write(bytearray(selector))
        elif mode == "6":
            import start
        else:
            mode = "1"

print("Starting J-Terminal...")
print("____________________________________")
jTerminal()
print("End of Line")