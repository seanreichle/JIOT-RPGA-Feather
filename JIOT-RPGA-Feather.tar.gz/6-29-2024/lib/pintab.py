from board import *

pintab = {
    1: LED
}
