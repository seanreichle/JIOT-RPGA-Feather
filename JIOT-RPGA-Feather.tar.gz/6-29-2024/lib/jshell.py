import gc
from os import statvfs

import board
import busio
import digitalio
 
def clearScreen():
        print(chr(27)+"[2J")
        
def shell():
    # ram
    gc.collect()
    rfree = gc.mem_free()

    # disk
    dfr = statvfs("/")  # board
    free = dfr[1] * dfr[3]
    bs = 2
    bs_sps = " " * bs
    dfree = (free)

    print("______________________________________________")
    print("J Loading...")
    # Derive unique ID
    JIOTID = "J7-M0LoRa"

    clearScreen()
    print(" -= J-IOT by Adventesia Corp. =- ")
    print("______________________________________________")
    print("Free RAM: " + str(rfree))
    print("Free Disk: " + str(dfree))
    print()
    userInput = ""

    while userInput != "exit":
        userInput = input("J >>") 
        try:
            if userInput == "cls" or userInput == "clear":
                clearScreen()
            elif userInput == "reboot" or userInput == "REBOOT":
                import reboot
            else:
                exec(userInput) 
        except:
            print("Bad Command")
            


shell()