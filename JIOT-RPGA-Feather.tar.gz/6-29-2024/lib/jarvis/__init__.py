# SPDX-FileCopyrightText: Copyright (c) 2023 Sean C Reichle, Adventesia Corp.
#
# SPDX-License-Identifier: NONE
"""
Aventesia Jarvis
================================================================================

Jarvis for CircuitPython

* Author(s): Sean C Reichle

Implementation Notes
--------------------

"""

__version__ = "0.0.0+auto.0"
__repo__ = ""

import board
import time
from digitalio import DigitalInOut, Direction, Pull

from .jarvis import Jarvis

try:
    from typing import Dict, Tuple
except ImportError:
    pass

try:
    #Unexpected Maker Feather S2
    # Init LDO2 Pin
    ldo2 = DigitalInOut(board.LDO2)
    ldo2.direction = Direction.OUTPUT

    def enable_LDO2(state):
        """Set the power for the second on-board LDO to allow no current draw when not needed."""
        ldo2.value = state
        # A small delay to let the IO change state
        time.sleep(0.035)

        
    # Make sure the 2nd LDO is turned on
    enable_LDO2(True)
except:
    pass