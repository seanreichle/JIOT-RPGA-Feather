from sys import exit
print("End of Line")
exit()

"""
rename_process("exit")
term.write("Rebooting Now...")
term.console.disconnect()
be.based.run("runparts /etc/hooks/disconnect.d/")
be.based.command.exec(pv[0]["root"] + "/bin/_waitforconnection.lja")
"""