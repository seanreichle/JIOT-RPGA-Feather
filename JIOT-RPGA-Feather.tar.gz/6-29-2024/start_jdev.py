### J-IOT
"""
Aventesia Jarvis
================================================================================
Jarvis for CircuitPython
J-IOT, JTerminal, JPicoWeb, JESPWep, J98, J7, JGlass, Jarvis, JarvisJS

* Author(s): Sean C Reichle

Implementation Notes
--------------------
JTerminal Dumptser Fire Kernal.... 
jSystem
"""

# Start
print("J Loading...")
print("________________________________________")


import board
import sys
from sys import exit
import time
import supervisor
from supervisor import runtime
from supervisor import reload
import storage

from time import monotonic, sleep
from microcontroller import reset, RunMode, on_next_reset

from os import chdir, sync
from digitalio import DigitalInOut, Direction, Pull
from analogio import AnalogIn, AnalogOut
try:
    import re
except:
    pass
    
    

#JNUX support
Version = "0.3.6-dev"
Circuitpython_supported = [(7, 3), (8, 0), (8, 1), (8, 2)]
dmesg = []
ndmesg = False  # disable dmesg for ram
access_log = []

##################################################################################################

# internal re-write of /boot.py and /code.py JTerminal Boot Loader J-IOT
# disable auto reload to stop unexpected reloads
supervisor.set_next_code_file(filename = 'code.py', reload_on_error = False, reload_on_success = False)
supervisor.runtime.autoreload = False

#
#jhttp Dependent Globals for Dynamic Web Server
print("Setting GLOBALS")
print("______________________________________________")

# Derive unique ID
JIOTID = "J7-S3Pro"

#J-IOT Start sequence: allocation of globals
jsys = object   #J DataStore, but it's global
jterm = object  #jterminal object user access
jcloud = object #jcloud object data object
jiot = object   #jcore object state machine
J = object      #Jarvis hypervisor object/ self
jhttp = object  #jhttp hypertext object
webled = object #TODO Replace this with a global object jGPIO to emulate all our IO, than can become real IO 


#jhttp Hypertext with hyperfuel mixed with hypercool for hypertool
jpyOutput = "Server Side jpy script output"
jpyRequest = "Client Request"
jpyRawRequest = ""
jpyClient = ""
jpyHeader = ""
jpyCode = ""
jpyFile = ""

##################################################################################################    
#Adventesia JSystem Start... global key/value store.

from jsystem import JSystem
jsys = JSystem()
jsys.setSystemName(JIOTID)
jsys.boot()
jsys.createkv("JIOTID", JIOTID)

##################################################################################################    

#-----------
#Dev.
from j98 import J98
j98Page = J98()
jsys.createkv("DevConsoleInput","")
jsys.createkv("DevConsoleOutput", "J98 Loaded: ok")

#-----------
##################################################################################################    

#platform enums
import  microcontroller
import digitalio
import analogio
#digital
jPin = microcontroller.Pin
jDigitalPin = digitalio.DigitalInOut
jdigitalOutput = digitalio.Direction.OUTPUT
jdigitalInput = digitalio.Direction.INPUT
#jdrive_mode = digitalio.drive_mode

#analog
jAnalogIn = analogio.AnalogIn
jAnalogOut = analogio.AnalogOut

#CircuitPython jGPIO
class fakeAnalog():
    value: int
    def __init__(self):
        self.value = 0
        
class fakeDigital():
    pin: object
    pinNum: int
    value: int
    enabled: bool
    assigned: bool
    fakePins: []  #fakePins become real pins
    direction : object
    
    def __init__(self):
        self.value = 0
        self.enabled = False
        self.assigned = False
        self.fakePins = dir(board)
        self.pin = microcontroller.Pin
        self.direction = jdigitalOutput
        
    def assign(aFakePin, newDirection):
        self.pin = aFakePin
        if newDirection == jdigitalOutput:
            self.direction = newDirection
        else:
            self.direction = jdigitalInput
      
        
##################################################################################################
print("________________________________________")
print("Starting JTerminal...")
import busio
from jterminal import termfunctions
from jterminal import jTerminal
jterm = jTerminal()
#jterm.setPins(board.IO16, board.IO17)
#jterm.assignUart(busio.UART(board.IO16, board.IO17, baudrate=9600))
jterm.setIdentity(JIOTID)
jterm.setjsys(jsys)

##################################################################################################
print("________________________________________")
print("Starting J-IOT...")
from jcore import core

import  microcontroller
import digitalio
import analogio

#globals to represent GPIO hookup
a0 = object
a1 = object
a2 = object
a3 = object

# Start the j-iot core
jiot = core()
jiot.setjsys(jsys)

try:
    jiot.setName(jterm.getIdentity())
except:
    jiot.setName(JIOTID)
    
#jiot requires 4 gpio to start.  
try:
    a0 = AnalogIn(board.A0)
    a1 = AnalogIn(board.A1)
    a2 = AnalogIn(board.A2)
    a3 = AnalogIn(board.A3)
except:
    a0 = fakeAnalog()
    a1 = fakeAnalog()
    a2 = fakeAnalog()
    a3 = fakeAnalog()
    
jiot.boot(a0,a1,a2,a3)
##################################################################################################
print("________________________________________")
print("Starting Jarvis...")
from jarvis import Jarvis
J = Jarvis()
J.setjsys(jsys)

J.boot()
J.run()

##################################################################################################
# WiFi credentials
#SSID="Jaskar"
#SSIDPASSWD="winner11"
#SSID="JediTemple"
SSID="Jaskarnet"
SSIDPASSWD="Winner2040"
print("________________________________________")
print("Starting Connecting to Network...")
import mdns
import wifi
import socketpool

def do_connect(ssid, password):
    wifi.radio.enabled = True
    print('Trying to connect to "%s"...' % ssid)
    try:
        wifi.radio.connect(ssid, password)
    except Exception as e:
        print("Exception", str(e))
    
do_connect(SSID, SSIDPASSWD)


##################################################################################################
print("________________________________________")
print("Starting Dynamic Web Server")
import mdns
from adafruit_jhttpserver import Server, Request, Response, Headers, Redirect, ChunkedResponse, FileResponse, JSONResponse, MIMETypes, GET, POST, PUT, DELETE, REQUEST_HANDLED_RESPONSE_SENT

mdns_server = mdns.Server(wifi.radio)
mdns_server.hostname = str(JIOTID)
mdns_server.advertise_service(service_type="_http", protocol="_tcp", port=80)

pool = socketpool.SocketPool(wifi.radio)
jhttp = Server(pool,"/LjinuxRoot/var/www/default", debug=True)

@jhttp.route("/")
def base(request: Request):
    return FileResponse(request, "index.html", "/LjinuxRoot/var/www/default")

@jhttp.route("/status")
def status(request: Request):
    return FileResponse(request, "status.jpy", "/LjinuxRoot/var/www/default")

@jhttp.route("/jterm")
def status(request: Request):
    return FileResponse(request, "jterm.jpy", "/LjinuxRoot/var/www/default")

@jhttp.route("/internal")
def status(request: Request):
    return FileResponse(request, "index.jpy", "/LjinuxRoot/var/www/default/internal")

@jhttp.route("/cpu", append_slash=True)
def cpu_information_handler(request: Request):
    import microcontroller

    data = {
        "temperature": microcontroller.cpu.temperature,
        "frequency": microcontroller.cpu.frequency,
        "voltage": microcontroller.cpu.voltage,
    }
    return JSONResponse(request, data)

@jhttp.route("/cycle", append_slash=True)
def getCycleClock(request: Request):
    data = {
        "age" : jiot.getAge(),
        "cycle": jiot.getCycleClock(),
    }
    return JSONResponse(request, data)

@jhttp.route("/soul", append_slash=True)
def getSoul(request: Request):
    data = {
        "key" : "time-ns:wave1-wave2-wave3-wave4",
        "soul" : jiot.soul,
        
    }
    return JSONResponse(request, data)

# Start the server.
jhttp.start(str(wifi.radio.ipv4_address))
J.setHost(str(wifi.radio.ipv4_address))

while jiot.webserver:
    if jpyRawRequest=="" :
        jterm.cpuCycle()
        jiot.cpuCycle()
        J.cpuCycle()
    pool_result = jhttp.poll()
    if pool_result == REQUEST_HANDLED_RESPONSE_SENT:
        jpyRawRequest = ""
        

