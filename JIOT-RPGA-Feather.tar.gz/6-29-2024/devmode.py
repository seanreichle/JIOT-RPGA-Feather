from storage import getmount, remount, disable_usb_drive

try:
    opts = ljinux.api.xarg()
except:
	pass
		
try:
    remount("/", False)
    f = open("/devm", "w")
    f.close()
    remount("/", True)
except:
    pass

del opts
del opts
ljinux.api.setvar("return", "1")